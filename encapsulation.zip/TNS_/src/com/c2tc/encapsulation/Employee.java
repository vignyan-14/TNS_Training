package com.c2tc.encapsulation;

public class Employee {

	private int eid;
	private String ename;
	
	public int getEid() {
		return eid;
	}
	
	public void setEid(int eid) {
		this.eid=eid;
	}
	public String getName() {
		return ename;
	}
	public void setName(String ename) {
		this.ename=ename;
	}
	
	public void display() {
		System.out.print("Employee detsils are : "+eid+","+ename);
		
	}
	
	public static void main(String[] args) {
		
		Employee ob = new Employee();
		ob.setEid(01);
		ob.setName("sai");
		ob.display();
//		System.out.println(ob.getEid());
//		System.out.println(ob.getName());
	}


}
