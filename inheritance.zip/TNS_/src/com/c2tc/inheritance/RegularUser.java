package com.c2tc.inheritance;

public class RegularUser extends User {

	int activeDaysInWeek;
	public RegularUser(int uid, String name, String email,int activeDaysInWeek) {
		super(uid, name, email);
		
		this.activeDaysInWeek=activeDaysInWeek;
	}
	@Override
	public String toString() {
        return super.toString() +" Active days :"+activeDaysInWeek;
    }
}
