package com.c2tc.abstraction;

public abstract class Payment {

	abstract void paymentMode();
	
	void printReceipt() {
		System.out.println("Receipt Printed");
	}
}
