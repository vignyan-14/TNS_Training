package com.c2tc.abstraction;

public class Main {
public static void main(String[] args) {
	Payment p1 = new UpiPayment();
	Payment p2 = new CashPayment();
	
	p1.paymentMode();
	p1.printReceipt();
	p2.paymentMode();
	p2.printReceipt();
}
}
