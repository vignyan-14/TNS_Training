package com.c2tc.abstraction;

public class CashPayment extends Payment {
	void paymentMode() {
		System.out.println("Paymnet is done via CASH");
	}

}
