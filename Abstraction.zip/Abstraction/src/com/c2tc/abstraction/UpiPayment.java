package com.c2tc.abstraction;

public class UpiPayment extends Payment {
	
	void paymentMode() {
		System.out.println("Paymnet is done via UPI");
	}

}
