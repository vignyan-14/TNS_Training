package com.c2tc.polymorphism;

public class Demo {

	public int mul(int a,int b) {
		int c = a*b;
		return c;
	}
	public float mul(float a,float b) {
		float c = a*b;
		return c;
	}
	
	public static void main(String[] args) {
		Demo ob = new Demo();
		System.out.println("Multiplication of Integer values : "+ob.mul(2, 3));
		System.out.println("Multiplication of Floating values  : "+ob.mul(2.1f, 3.1f));
	}
	
}
