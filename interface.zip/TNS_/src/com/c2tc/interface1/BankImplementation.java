package com.c2tc.interface1;

public class BankImplementation implements Bank{
	
	@Override
	public void withdraw(Account acc,double amount) {
		if(acc.getBalance()-amount>MinBal) {
			acc.setBalance(acc.getBalance()-amount);
			System.out.println("The Balance After Withdraw : "+ acc.getBalance());
		}
		else {
			System.out.println("Insufficient Funds...");
		}
	}
	
	@Override
	public void deposit(Account acc,double amount) {
		if (amount>DepositLimit) {
			System.out.print("Exceeding the deposit Limit...");
		}
		else {
			acc.setBalance(acc.getBalance()+amount);
			System.out.print("Balance After Deposit : "+acc.getBalance());
		}
	}
}
