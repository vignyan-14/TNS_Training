package com.c2tc.interface1;

public interface Bank {

	final double MinBal=2000;
	final double DepositLimit=50000;
	void withdraw(Account acc, double amount);
	void deposit(Account acc, double amount);
	
}
