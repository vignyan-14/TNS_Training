package com.c2tc.interface1;

public class Main {

	public static void main(String[] args) {
		Account acc=new Account(100,"Sai",9000);
		
		BankImplementation bank = new BankImplementation();
		bank.withdraw(acc, 2000);
		bank.deposit(acc, 20000);
	}
	
}
